export const environment = {
  production: true,
  apiAddress: 'https://jguim002.com:3001'
};
