import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tos',
  templateUrl: './tos.component.html',
  styleUrls: ['./tos.component.scss']
})
export class TOSComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
