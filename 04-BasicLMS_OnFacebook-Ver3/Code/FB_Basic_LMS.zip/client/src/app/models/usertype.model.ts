export enum UsertypeModel {
  Master = 2,
  Admin = 1,
  Instructor = 0,
  Student = 4,
  Guest = 3
}
